import React from 'react';

const Spinner = () => {
  return <span className='loading loading-ring loading-s'></span>;
};

export default Spinner;
